function main(_unneededvar) {
    console.log("\nGAME HELP\nLook at https://github.com/SejDevStuff/terminal-currency-game/blob/main/commands.md for thorough documentation of all available commands!\n")
}

module.exports = {
    main
}