# terminal-currency-game
Terminal Currency Game - NODEJS
---
This originated from a Economy discord bot I made, this may just follow the trend of any other project and land in my project landfill unfinished, or it may take off and get a few versions released. I don't know.

### WARNING!
DO NOT download this by cloning the repo, repo commits always tend to have some unfinished thing in them. Use the releases tab [handy link](https://github.com/SejDevStuff/terminal-currency-game/releases)

## Want to test it out?
You need nodejs and npm installed.
Check out the releases tab [handy link](https://github.com/SejDevStuff/terminal-currency-game/releases) and download the latest zip or tar.gz file, then install prompt-sync (``npm install prompt-sync --save-dev``) and node-fetch (``npm install node-fetch --save``) and then do ``npm start`` and everything should go smoothly! If not, tell me

## Why are the releases open source?
Open-source projects are epic. And I want to make this game as customisable as possible, don't worry I will make sure you can't cheat, somehow.
